//FOLLOW DEVELOPER CHANNEL 
//https://whatsapp.com/channel/0029VaieFO2HFxOtUtwLvQ0b
const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["923255156992@s.whatsapp.net"]
global.nomerOwner = "923255156992" 
global.nomorOwner = ['923255156992']
global.namaDeveloper = "𝐊͠𝐀̋𝐒̋͢𝐇̋𝐌̋͢𝐈̋𝐑̋͢𝐈" // jangn diubh bng hargai dev
global.namaBot = "KASHMIRI V4"
global.packname = "𝐊͠𝐀̋𝐒̋͢𝐇̋𝐌̋͢𝐈̋𝐑̋͢𝐈" // jangan di ubah
global.author = "𝐊͠𝐀̋𝐒̋͢𝐇̋𝐌̋͢𝐈̋𝐑̋͢𝐈 👽" // jangan di ubah
global.thumb = fs.readFileSync("./rog.mp4")
global.ThM = 'https://files.catbox.moe/m0u5ja.jpg'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})